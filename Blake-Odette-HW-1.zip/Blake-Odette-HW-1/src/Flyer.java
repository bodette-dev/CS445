public interface Flyer
{
	public void fly();
}