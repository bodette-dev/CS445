How to build and run each program:
1. Navigate to the folder containing the .java files by entering the src folder. 
2. In order to run the CompileCode.sh file, you will need permission. Type "chmod +x CompileCode.sh" in order to be able to execute the script. 
3. Execute the script by typing "./CompileCode.sh"
4. In order to run each source code file, type "java FILENAME" without the .java extention. For example, to run the TestCreature.java file, type "java TestCreature"
